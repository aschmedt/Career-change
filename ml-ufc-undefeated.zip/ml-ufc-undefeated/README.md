# UFC Undefeated Fight Predictor

End-to-end pipeline to train a model on historical **undefeated vs opponent** fights and predict the outcome probability for upcoming matchups.

## Features
- Re-usable **feature engineering** (totals, win rates, age/reach/height/odds deltas)
- Sklearn **Pipeline**: impute → scale → one-hot → GradientBoostingClassifier
- **5-fold CV** metrics during training
- Robust to the odds column typo: `undfeated_fighter_odds` vs `undefeated_fighter_odds`
- CLI scripts: `train.py` and `predict.py`

## Quickstart

### 1) Install
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2) Train
Put your historical file (e.g., `data/Undefeated_Fighters 3.xlsx`) in `data/` and run:
```bash
python -m src.train   --train_path "data/Undefeated_Fighters 3.xlsx"   --sheet_name Sheet1   --model_out models/undefeated_best_model_GradBoost.pkl   --metrics_out models/cv_metrics.json   --expected_cols_out models/expected_columns.json
```

### 3) Predict upcoming fights
Prepare a CSV/XLSX with **pre-fight** inputs matching the training schema (no `winner`/`undefeated_won`). Then:
```bash
python -m src.predict   --model_path models/undefeated_best_model_GradBoost.pkl   --input_path data/upcoming_fights.xlsx   --output_path predictions.csv   --sheet_name Sheet1   --expected_cols_path models/expected_columns.json   --threshold 0.5
```

Outputs:
- `undefeated_win_prob` = probability the undefeated fighter wins
- `pick` = `"Undefeated"` or `"Opponent"` at the chosen threshold

## Notes
- Leave unknown numeric fields blank; the pipeline imputes them.
- Either `undefeated_fighter_odds` **or** `undfeated_fighter_odds` is accepted.
- You can swap models (e.g., RandomForest, XGBoost) in `src/train.py`.
