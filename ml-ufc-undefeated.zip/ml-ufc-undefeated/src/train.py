from __future__ import annotations
import argparse, json, os, joblib
from pathlib import Path
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate
from .features import engineer_features, split_features_target

def load_data(path: str, sheet_name: str | None = None) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in {".xls", ".xlsx", ".xlsm", ".xlsb", ".odf", ".ods", ".odt"}:
        return pd.read_excel(p, sheet_name=sheet_name if sheet_name is not None else 0)
    return pd.read_csv(p)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_path", required=True)
    ap.add_argument("--sheet_name", default=None)
    ap.add_argument("--model_out", default="models/undefeated_best_model_GradBoost.pkl")
    ap.add_argument("--metrics_out", default="models/cv_metrics.json")
    ap.add_argument("--expected_cols_out", default="models/expected_columns.json")
    args = ap.parse_args()

    df_raw = load_data(args.train_path, args.sheet_name)
    df = engineer_features(df_raw)
    X, y, cat_cols, num_cols = split_features_target(df)

    numeric_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    preprocess = ColumnTransformer([
        ("num", numeric_transformer, num_cols),
        ("cat", categorical_transformer, cat_cols),
    ])

    model = GradientBoostingClassifier(random_state=42)
    pipe = Pipeline([("preprocess", preprocess), ("model", model)])

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scoring = {"accuracy": "accuracy", "roc_auc": "roc_auc", "f1": "f1"}
    cv_res = cross_validate(pipe, X, y, cv=cv, scoring=scoring)

    metrics = {m+"_mean": float(cv_res["test_"+m].mean()) for m in ["accuracy", "roc_auc", "f1"]}
    metrics.update({m+"_std": float(cv_res["test_"+m].std()) for m in ["accuracy", "roc_auc", "f1"]})
    metrics["n_samples"] = int(len(df))
    metrics["n_features_num"] = len(num_cols)
    metrics["n_features_cat"] = len(cat_cols)

    os.makedirs(os.path.dirname(args.metrics_out), exist_ok=True)
    with open(args.metrics_out, "w") as f:
        json.dump(metrics, f, indent=2)

    pipe.fit(X, y)
    os.makedirs(os.path.dirname(args.model_out), exist_ok=True)
    joblib.dump(pipe, args.model_out)

    os.makedirs(os.path.dirname(args.expected_cols_out), exist_ok=True)
    with open(args.expected_cols_out, "w") as f:
        json.dump({"numeric": num_cols, "categorical": cat_cols}, f, indent=2)

    print("Saved model, metrics, and expected columns.")

if __name__ == "__main__":
    main()
