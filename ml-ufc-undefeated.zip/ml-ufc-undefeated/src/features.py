from __future__ import annotations
import pandas as pd
import numpy as np

LEAKY_COLS = [
    "undefeated_won",
    "winner",
    "undefeated_fighter",
    "opponent",
    "undefeated_win_rate",
]

def _coalesce_odds_columns(df: pd.DataFrame) -> pd.DataFrame:
    if "undfeated_fighter_odds" not in df.columns and "undefeated_fighter_odds" in df.columns:
        df["undfeated_fighter_odds"] = df["undefeated_fighter_odds"]
    return df

def engineer_features(df_in: pd.DataFrame) -> pd.DataFrame:
    df = df_in.copy()
    df = _coalesce_odds_columns(df)
    if {"undefeated_wins", "undefeated_losses"}.issubset(df.columns):
        df["undefeated_total_fights"] = df["undefeated_wins"].fillna(0) + df["undefeated_losses"].fillna(0)
    if {"opponent_wins", "opponent_losses"}.issubset(df.columns):
        df["opponent_total_fights"] = df["opponent_wins"].fillna(0) + df["opponent_losses"].fillna(0)
    if {"undefeated_wins", "undefeated_total_fights"}.issubset(df.columns):
        denom = df["undefeated_total_fights"].replace({0: np.nan})
        df["undefeated_win_rate"] = df["undefeated_wins"] / denom
    if {"opponent_wins", "opponent_total_fights"}.issubset(df.columns):
        denom = df["opponent_total_fights"].replace({0: np.nan})
        df["opponent_win_rate"] = df["opponent_wins"] / denom
    if {"undefeated_fighter-age", "opponent_age"}.issubset(df.columns):
        df["age_difference"] = df["undefeated_fighter-age"] - df["opponent_age"]
    if {"undefeated_fighter_reach_cm", "opponent_reach"}.issubset(df.columns):
        df["reach_difference"] = df["undefeated_fighter_reach_cm"] - df["opponent_reach"]
    if {"undefeated_fighter_height_cm", "opponent_height"}.issubset(df.columns):
        df["height_difference"] = df["undefeated_fighter_height_cm"] - df["opponent_height"]
    if {"undfeated_fighter_odds", "opponent_odds"}.issubset(df.columns):
        df["odds_difference"] = df["undfeated_fighter_odds"] - df["opponent_odds"]
    return df

def split_features_target(df_in: pd.DataFrame):
    df = df_in.copy()
    y = df["undefeated_won"].astype(int) if "undefeated_won" in df.columns else None
    X = df.drop(columns=[c for c in LEAKY_COLS if c in df.columns], errors="ignore")
    cat_cols = X.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
    num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    return X, y, cat_cols, num_cols
