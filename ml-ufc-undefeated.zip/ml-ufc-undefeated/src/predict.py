from __future__ import annotations
import argparse, json, os, joblib
from pathlib import Path
import numpy as np
import pandas as pd
from .features import engineer_features, split_features_target

def load_data(path: str, sheet_name: str | None = None) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in {".xls", ".xlsx", ".xlsm", ".xlsb", ".odf", ".ods", ".odt"}:
        return pd.read_excel(p, sheet_name=sheet_name if sheet_name is not None else 0)
    return pd.read_csv(p)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model_path", required=True)
    ap.add_argument("--input_path", required=True)
    ap.add_argument("--output_path", required=True)
    ap.add_argument("--sheet_name", default=None)
    ap.add_argument("--expected_cols_path", default=None)
    ap.add_argument("--threshold", type=float, default=0.5)
    args = ap.parse_args()

    pipe = joblib.load(args.model_path)

    df_raw = load_data(args.input_path, args.sheet_name)
    df = engineer_features(df_raw)
    X, y, cat_cols, num_cols = split_features_target(df)

    expected_num, expected_cat = None, None
    if args.expected_cols_path and os.path.exists(args.expected_cols_path):
        with open(args.expected_cols_path, "r") as f:
            schema = json.load(f)
            expected_num, expected_cat = schema.get("numeric", []), schema.get("categorical", [])
    else:
        pre = pipe.named_steps.get("preprocess")
        if pre and hasattr(pre, "transformers_"):
            expected_num = list(pre.transformers_[0][2])
            expected_cat = list(pre.transformers_[1][2])

    if expected_num and expected_cat:
        for col in expected_num + expected_cat:
            if col not in X.columns:
                X[col] = np.nan
        X = X[expected_num + expected_cat]

    proba = pipe.predict_proba(X)[:, 1]
    pick = (proba >= args.threshold).astype(int)
    pick_label = np.where(pick == 1, "Undefeated", "Opponent")

    out = df_raw.copy()
    out["undefeated_win_prob"] = proba
    out["pick"] = pick_label
    out.to_csv(args.output_path, index=False)
    print("Saved predictions to", args.output_path)

if __name__ == "__main__":
    main()
